<h2>Tipy na obsluhu</h2>
<p>Obsluha na používateľskom rozhraní je podobná štandardnému správcovi súborov operačného systému. Drag and Drop však nie je možné používať s mobilnými prehliadačmi. </p>
<ul>
	<li>Kliknutím pravým tlačidlom alebo dlhým klepnutím zobrazíte kontextové menu.</li>
	<li>Presuňte myšou do stromu priečinkov alebo do aktuálneho pracovného priestoru a presuňte / kopírujte položky.</li>
	<li>Výber položky v pracovnom priestore môžete rozšíriť pomocou klávesov Shift alebo Alt (Možnosť).</li>
	<li>Premiestnite súbory a priečinky do cieľovej zložky alebo do pracovného priestoru.</li>
	<li>Dialog odovzdávania môže prijímať dáta schránky alebo zoznamy adries URL a pritiahnuť a odísť z iných prehliadačov alebo správcov súborov.</li>
	<li>Potiahnutím spustite stlačením klávesu Alt (Možnosť) pretiahnite do vonkajšieho prehliadača. Táto funkcia sa prevezme pomocou prehliadača Google Chrome.</li>
</ul>
