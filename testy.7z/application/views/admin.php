<div class="container">
    <div class="row">
        <div class="col-md-12">
            Panel uzytkownika
        </div>
    </div>
</div>

