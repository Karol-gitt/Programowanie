<!DOCTYPE html>
<html lang="pl">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <base href="<?php echo base_url(); ?>">
    <title>Testy</title>

    <link href="./css/bootstrap.united.min.css" rel="stylesheet">   
        
    <link href="./css/jquery.dataTables.min.css" rel="stylesheet" type="text/css"/>
    <link href="./css/bootstrap-toggle.css" rel="stylesheet" type="text/css"/>
    <link href="./css/fuelux.min.css" rel="stylesheet" type="text/css"/>
    <link href="./css/bootstrap-chosen.css" rel="stylesheet" type="text/css"/>
    <link href="./css/jquery.cookiebar.css" rel="stylesheet" type="text/css"/>
    
    <link href="./css/style.css" rel="stylesheet" type="text/css"/>
    
    <script src="./js/jquery.js"></script>    
    
  </head>

  <body class="fuelux">
    