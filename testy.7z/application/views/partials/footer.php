    <!-- Placed at the end of the document so the pages load faster -->
    <script src="./js/bootstrap.min.js"></script>
    <script src="./js/jquery.form.js"></script>
    <script src="./js/jquery.dataTables.min.js" type="text/javascript"></script>
    <script src="./js/dataTables.bootstrap.js" type="text/javascript"></script>
    <script src="./js/bootstrap-toggle.js" type="text/javascript"></script>
    <script src="./js/fuelux.min.js" type="text/javascript"></script>
    <script src="./js/chosen.jquery.min.js" type="text/javascript"></script>
    <script src="./plugins/ckeditor/ckeditor.js" type="text/javascript"></script>
    <script src="./js/md5.js" type="text/javascript"></script>
    <script src="./js/spin.min.js" type="text/javascript"></script>
    <script src="./js/jquery-ui.min.js" type="text/javascript"></script>
    <script src="./js/jquery.cookiebar.js" type="text/javascript"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.5/MathJax.js?config=TeX-MML-AM_CHTML" type="text/javascript"></script>
    <script src="./js/moment.js"></script>
    <script src="./js/application.js"></script>
  </body>
</html>